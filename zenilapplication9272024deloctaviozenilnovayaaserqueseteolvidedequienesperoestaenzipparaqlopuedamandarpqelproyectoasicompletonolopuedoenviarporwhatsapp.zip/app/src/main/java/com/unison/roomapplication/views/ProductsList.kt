package com.unison.roomapplication.views

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.sharp.ArrowBack
import androidx.compose.material.icons.sharp.Add
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.currentCompositionLocalContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.unison.roomapplication.R
import com.unison.roomapplication.model.Producto
import com.unison.roomapplication.navigation.NavDestinations
import com.unison.roomapplication.view_models.ProductoEvent
import com.unison.roomapplication.view_models.ProductosViewModel

@Composable
fun ProductsList(viewModel: ProductosViewModel, navController: NavController, modifier: Modifier = Modifier) {
    var productsList by remember { mutableStateOf(listOf<Producto>()) }

    viewModel.getProducts().observeForever{
        productsList = it
    }

    Column (
        modifier = Modifier.background(colorResource(id = R.color.teal).copy(alpha = 0.2f))
    ) {
        ProductsListHeader(navController)
        ProductListBody(productsList)
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(15.dp)
        ,
        contentAlignment = Alignment.BottomEnd
    ){
        
        FloatingActionButton(
            onClick = { navController.navigate(NavDestinations.ProductsForm.route)},
            containerColor = colorResource(id = R.color.purple),
            modifier = Modifier.size(60.dp)) {
            Icon(
                imageVector = Icons.Sharp.Add,
                contentDescription = "Agregar",
                tint = colorResource(id = R.color.bone),
                modifier = Modifier
                    .fillMaxSize(),

                )
        }
    }

}

//@Preview(showBackground = true)
//@Composable
//fun ProductsListPreview() {
//    val viewModel = ProductosViewModel()
//    ProductsList(viewModel)
//
//}

@Composable
fun ProductsListHeader(navController: NavController, modifier: Modifier = Modifier) {
    Box(
        modifier = Modifier
            .background(
                colorResource(id = R.color.dark_purple).copy(alpha = 0.9f),
                shape = RoundedCornerShape(bottomEnd = 40.dp, bottomStart = 40.dp)
            )
            .height(120.dp)
    ){
        Box(
            modifier = Modifier
                .background(
                    colorResource(id = R.color.purple).copy(alpha = 0.9f),
                    shape = RoundedCornerShape(bottomEnd = 30.dp, bottomStart = 30.dp)
                )
                .height(100.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomEnd = 20.dp, bottomStart = 20.dp)),
        ){
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)

                ,
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {

            Box{
                FloatingActionButton(
                    onClick = {  navController.navigate(NavDestinations.Home.route) },
                    containerColor = colorResource(id = R.color.dark_purple).copy(0.6f),
                    shape = CircleShape,
                    modifier = Modifier.offset(x = -130.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Sharp.ArrowBack,
                        contentDescription = "Go back",
                        tint = colorResource(id = R.color.white),
                        modifier = Modifier.size(30.dp)
                    )
                }
                Text(
                    modifier = Modifier.offset(y = 20.dp),
                    text = "Productos",
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Bold,
                    color = colorResource(id = R.color.bone),
                    letterSpacing = -1.sp
                )
            }


            }
        }
    }

}

@Composable
fun ProductListBody(products: List<Producto>, modifier: Modifier = Modifier) {
    Box(modifier = Modifier
        .fillMaxSize()
    ){
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            LazyColumn (
                modifier = Modifier
                    .padding(10.dp)
                    .fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(15.dp)
            ){
                items(products) {
                    ProductoItem(it)
                }
            }
        }
    }
}

@Composable
fun ProductoItem(product: Producto, modifier: Modifier = Modifier) {

    val backgroundShape = RoundedCornerShape(12.dp)

    Box(Modifier.padding(top=10.dp)){
        Box (
            modifier = Modifier
                .shadow(
                    elevation = 15.dp,
                    spotColor = Color.Black,
                    ambientColor = Color.Blue,
                    shape = backgroundShape
                )
                .background(colorResource(id = R.color.bone))
                .fillMaxWidth()
                .padding(vertical = 10.dp)
                .height(120.dp)

            ,
            contentAlignment = Alignment.Center
        ){
            Row(
                modifier= Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start,
            ) {
                Box(
                    modifier = Modifier
                        .width(100.dp)
                        .height(100.dp)
                        .background(
                            colorResource(id = R.color.gray),
                            shape = RoundedCornerShape(10.dp)
                        )
                )

                Column (
                    verticalArrangement = Arrangement.SpaceBetween,
                    horizontalAlignment = Alignment.Start,
                    modifier = Modifier
                        .padding(start = 10.dp)
                        .fillMaxSize()
                ) {
                    Column(modifier = Modifier){
                        Text(
                            text = product.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black,
                            maxLines = 1,
                            softWrap = true,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            modifier = Modifier.padding(top = 5.dp),
                            text = "$${product.price - .01}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = colorResource(id = R.color.purple)
                        )
                    }
                    Column{
                        Text(
                            text = product.description,
                            overflow = TextOverflow.Ellipsis,
                            maxLines = 2,
                            softWrap = true,
                            fontSize = 12.sp,
                            color = colorResource(id = R.color.dark_purple).copy(alpha = .5f)
                        )
                    }
                }
                Column {
                    Text(text = "Eliminar")
                }
            }
        }
    }



}


package com.unison.roomapplication.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.unison.roomapplication.room.ProductDatabase
import com.unison.roomapplication.views.Home
import com.unison.roomapplication.views.PresentationCard
import com.unison.roomapplication.views.ProductsList
import com.unison.roomapplication.views.ProductsForm
import com.unison.roomapplication.view_models.ProductosViewModel

@Composable
fun NavManager(modifier: Modifier = Modifier) {
    val navController = rememberNavController()

    val db = ProductDatabase.getDatabase(LocalContext.current)
    val productosDao = db.productsDao()

    val productosViewModel = ProductosViewModel(productosDao)

    NavHost(navController = navController, startDestination = "home" ){
        composable(NavDestinations.Home.route) { Home(navController) }
        composable(NavDestinations.PresentationCard.route) { PresentationCard(navController) }
        composable(NavDestinations.ProudctsList.route) { ProductsList(productosViewModel, navController) }
        composable(NavDestinations.ProductsForm.route) { ProductsForm(navController, productosViewModel) }


    }
}
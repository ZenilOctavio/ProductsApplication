package com.unison.roomapplication.view_models

sealed interface ProductoEvent {
    data class CreateProducto(val nombre: String, val descripcion: String, val precio: String, val fecha: String): ProductoEvent

}
package com.unison.roomapplication.view_models

import android.util.Log
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import com.unison.roomapplication.model.Producto
import com.unison.roomapplication.room.ProductsDatabaseDao
import com.unison.roomapplication.state.ProductsModelViewState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import androidx.lifecycle.asLiveData
import com.unison.roomapplication.utils.stringToDouble


class ProductosViewModel(
    private val dao: ProductsDatabaseDao
) : ViewModel() {

    private val state = MutableStateFlow(ProductsModelViewState())


   fun getProducts() = dao.getAllProducts().asLiveData(viewModelScope.coroutineContext)




    fun onEvent(event: ProductoEvent){
        when(event){
            is ProductoEvent.CreateProducto -> {
                val nombre = event.nombre
                val descripcion = event.descripcion
                val precio = stringToDouble(event.precio)
                val fecha = event.fecha

                if (nombre.isBlank() || descripcion.isBlank() || precio == null || fecha == null){
                    return
                }

                val producto = Producto(
                    name = nombre,
                    description = descripcion,
                    price = precio,
                    date = fecha.toString())

                viewModelScope.launch {
                    dao.insertProduct(producto)

                }

                Log.d("ProductoViewModel", "Producto creado: $producto")

            }
        }
    }
}
